package com.sxv.gamespace

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import android.util.Log
import rikka.shizuku.Shizuku

/**
 * NativeBridge
 * ------------------------------------------------------------
 * Satu-satunya pintu masuk untuk menjalankan perintah shell di
 * seluruh aplikasi. Alurnya:
 *
 *   UI / FloatingService
 *        │  exec(cmd)
 *        ▼
 *   NativeBridge.exec(cmd)
 *        │  1) nativeValidateCommand(cmd)   ─┐ native C++
 *        │     - blacklist animation_scale  │ (SxvCoreEngine)
 *        │     - whitelist prefix           ─┘
 *        ▼
 *   ISxvShellService (proses shell milik Shizuku)
 *        │  2) benar-benar dieksekusi di sini
 *        ▼
 *   hasil dikembalikan ke caller
 *
 * Command yang tidak lolos validasi native TIDAK PERNAH sampai
 * ke Shizuku — ini mencegah command berbahaya lolos meski ada
 * bug di lapisan UI.
 */
object NativeBridge {

    private const val TAG = "NativeBridge"
    private const val USER_SERVICE_REQUEST_CODE = 1001

    init {
        System.loadLibrary("sxvcore")
    }

    // ---- JNI native methods (diimplementasikan di SxvCoreEngine.cpp) ----
    private external fun nativeInit()
    private external fun nativeValidateCommand(rawCommand: String): String?
    private external fun nativeReadSystemStats(): FloatArray

    data class SystemStats(
        val cpuUsagePercent: Float,
        val totalRamKb: Long,
        val availableRamKb: Long,
    )

    // ---- Status Shizuku ----
    private var shellService: ISxvShellService? = null
    var onShizukuStateChanged: ((connected: Boolean) -> Unit)? = null

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName(BuildConfigPlaceholder.APPLICATION_ID, SxvShellService::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("shell_service")
        .debuggable(false)
        .version(1)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            shellService = ISxvShellService.Stub.asInterface(binder)
            Log.i(TAG, "SxvShellService terhubung, UID=${shellService?.runningUid}")
            onShizukuStateChanged?.invoke(true)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            shellService = null
            Log.w(TAG, "SxvShellService terputus")
            onShizukuStateChanged?.invoke(false)
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.i(TAG, "Shizuku binder diterima, cek permission...")
        requestShizukuPermissionIfNeeded()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.w(TAG, "Shizuku binder mati")
        shellService = null
        onShizukuStateChanged?.invoke(false)
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == USER_SERVICE_REQUEST_CODE &&
                grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                bindUserService()
            } else {
                Log.w(TAG, "Izin Shizuku ditolak pengguna")
                onShizukuStateChanged?.invoke(false)
            }
        }

    fun initialize() {
        nativeInit()
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
    }

    fun release() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
    }

    /** true jika proses Shizuku terdeteksi hidup (belum tentu punya izin). */
    fun isShizukuAvailable(): Boolean =
        try {
            Shizuku.pingBinder()
        } catch (t: Throwable) {
            false
        }

    private fun requestShizukuPermissionIfNeeded() {
        if (Shizuku.isPreV11()) {
            Log.e(TAG, "Versi Shizuku terlalu lama, harap perbarui")
            return
        }
        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            bindUserService()
        } else {
            Shizuku.requestPermission(USER_SERVICE_REQUEST_CODE)
        }
    }

    /**
     * Dipanggil dari layar Setup ketika pengguna menekan
     * "Hubungkan via Shizuku". Untuk jalur Wireless Debugging
     * (port + kode pairing), proses pairing sesungguhnya
     * dilakukan oleh aplikasi Shizuku itu sendiri (yang sudah
     * mengimplementasikan protokol ADB pairing secara matang) —
     * lihat catatan arsitektur di SxvCoreEngine.h. Di sini kita
     * hanya menunggu binder Shizuku aktif lalu meminta izin.
     */
    fun connectShizuku() {
        if (isShizukuAvailable()) {
            requestShizukuPermissionIfNeeded()
        } else {
            Log.w(TAG, "Shizuku belum berjalan — arahkan pengguna membuka aplikasi Shizuku")
            onShizukuStateChanged?.invoke(false)
        }
    }

    private fun bindUserService() {
        try {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        } catch (t: Throwable) {
            Log.e(TAG, "bindUserService gagal", t)
            onShizukuStateChanged?.invoke(false)
        }
    }

    fun isReady(): Boolean = shellService != null

    /**
     * Titik eksekusi utama. Mengembalikan output shell, atau null
     * jika command ditolak validasi native atau layanan belum siap.
     */
    fun exec(rawCommand: String): String? {
        val validated = nativeValidateCommand(rawCommand)
        if (validated == null) {
            Log.w(TAG, "Command ditolak validasi native: $rawCommand")
            return null
        }
        val service = shellService ?: run {
            Log.w(TAG, "ISxvShellService belum terhubung")
            return null
        }
        return try {
            service.exec(validated)
        } catch (t: Throwable) {
            Log.e(TAG, "exec via Shizuku gagal", t)
            null
        }
    }

    fun execFireAndForget(rawCommand: String) {
        val validated = nativeValidateCommand(rawCommand) ?: run {
            Log.w(TAG, "Command ditolak validasi native: $rawCommand")
            return
        }
        try {
            shellService?.execFireAndForget(validated)
        } catch (t: Throwable) {
            Log.e(TAG, "execFireAndForget via Shizuku gagal", t)
        }
    }

    /** Statistik CPU/RAM lokal untuk Performance Monitor overlay. */
    fun readSystemStats(): SystemStats {
        val raw = nativeReadSystemStats()
        return SystemStats(
            cpuUsagePercent = raw.getOrElse(0) { 0f },
            totalRamKb = raw.getOrElse(1) { 0f }.toLong(),
            availableRamKb = raw.getOrElse(2) { 0f }.toLong(),
        )
    }
}

/**
 * Placeholder kecil agar file ini mandiri tanpa bergantung pada
 * kelas BuildConfig yang di-generate Gradle. Di project nyata,
 * ganti seluruh referensi `BuildConfigPlaceholder.APPLICATION_ID`
 * dengan `BuildConfig.APPLICATION_ID` (import com.sxv.gamespace.BuildConfig).
 */
private object BuildConfigPlaceholder {
    const val APPLICATION_ID = "com.sxv.gamespace"
}

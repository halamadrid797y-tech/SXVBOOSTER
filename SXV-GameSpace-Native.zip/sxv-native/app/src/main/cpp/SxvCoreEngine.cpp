#include "SxvCoreEngine.h"

#include <jni.h>
#include <android/log.h>

#include <fstream>
#include <sstream>
#include <array>
#include <mutex>
#include <memory>

#define LOG_TAG "SxvCoreEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace sxv {

// ------------------------------------------------------------
// Daftar substring yang DILARANG BERSYARAT — mengubah skala
// animasi sistem berisiko menyebabkan glitch UI/instabilitas.
// Ini adalah aturan tetap, tidak bisa dinonaktifkan dari luar.
// ------------------------------------------------------------
static const std::array<const char*, 3> kBlacklistedSubstrings = {
        "window_animation_scale",
        "transition_animation_scale",
        "animator_duration_scale",
};

// Prefix perintah yang diizinkan untuk fitur-fitur SXV Booster.
// Command di luar daftar ini ditolak oleh validateCommand().
static const std::array<const char*, 12> kAllowedPrefixes = {
        "wm density",
        "settings put global sync_enabled",
        "settings put global angle_gl_driver_selection_pkgs",
        "setprop debug.hwui.renderer",
        "appops set",
        "cmd notification allow_listener",
        "dumpsys deviceidle whitelist",
        "pm trim-caches",
        "am kill-all",
        "am force-stop",
        "am start",
        "monkey -p",
};

SxvCoreEngine::SxvCoreEngine() = default;

bool SxvCoreEngine::isBlacklisted(const std::string& cmd) const {
    for (const auto* bad : kBlacklistedSubstrings) {
        if (cmd.find(bad) != std::string::npos) {
            return true;
        }
    }
    return false;
}

bool SxvCoreEngine::isWhitelistedPrefix(const std::string& cmd) const {
    for (const auto* prefix : kAllowedPrefixes) {
        if (cmd.rfind(prefix, 0) == 0) { // cmd.startsWith(prefix)
            return true;
        }
    }
    return false;
}

std::optional<std::string> SxvCoreEngine::validateCommand(const std::string& rawCommand) {
    // Trim spasi di awal/akhir.
    size_t start = rawCommand.find_first_not_of(" \t");
    size_t end = rawCommand.find_last_not_of(" \t");
    if (start == std::string::npos) {
        LOGW("validateCommand: command kosong ditolak");
        return std::nullopt;
    }
    std::string cmd = rawCommand.substr(start, end - start + 1);

    if (isBlacklisted(cmd)) {
        LOGE("validateCommand: DITOLAK (blacklist) -> %s", cmd.c_str());
        return std::nullopt;
    }

    if (!isWhitelistedPrefix(cmd)) {
        LOGW("validateCommand: DITOLAK (bukan whitelist) -> %s", cmd.c_str());
        return std::nullopt;
    }

    LOGI("validateCommand: OK -> %s", cmd.c_str());
    return cmd;
}

SxvCoreEngine::SystemStats SxvCoreEngine::readSystemStats() {
    SystemStats stats;

    // ---- CPU usage dari /proc/stat ----
    // Baris pertama /proc/stat: cpu  user nice system idle iowait irq softirq
    std::ifstream statFile("/proc/stat");
    if (statFile.is_open()) {
        std::string line;
        std::getline(statFile, line);
        std::istringstream iss(line);
        std::string cpuLabel;
        long user, nice, system, idle, iowait = 0, irq = 0, softirq = 0;
        iss >> cpuLabel >> user >> nice >> system >> idle >> iowait >> irq >> softirq;

        long idleTicks = idle + iowait;
        long totalTicks = user + nice + system + idle + iowait + irq + softirq;

        if (prevTotalTicks_ > 0) {
            long deltaTotal = totalTicks - prevTotalTicks_;
            long deltaIdle = idleTicks - prevIdleTicks_;
            if (deltaTotal > 0) {
                stats.cpuUsagePercent =
                        100.0f * static_cast<float>(deltaTotal - deltaIdle) /
                        static_cast<float>(deltaTotal);
            }
        }
        prevIdleTicks_ = idleTicks;
        prevTotalTicks_ = totalTicks;
    } else {
        LOGW("readSystemStats: gagal membuka /proc/stat");
    }

    // ---- RAM dari /proc/meminfo ----
    std::ifstream memFile("/proc/meminfo");
    if (memFile.is_open()) {
        std::string key;
        long value;
        std::string unit;
        while (memFile >> key >> value >> unit) {
            if (key == "MemTotal:") stats.totalRamKb = value;
            else if (key == "MemAvailable:") stats.availableRamKb = value;
            if (stats.totalRamKb && stats.availableRamKb) break;
        }
    } else {
        LOGW("readSystemStats: gagal membuka /proc/meminfo");
    }

    return stats;
}

} // namespace sxv

// ==============================================================
// JNI BRIDGE
// Fungsi-fungsi berikut dipanggil dari NativeBridge.kt melalui
// deklarasi `external fun`. Nama fungsi mengikuti konvensi JNI:
// Java_<package>_<Kelas>_<namaFungsi> (paket: com.sxv.gamespace)
// ==============================================================

namespace {
std::unique_ptr<sxv::SxvCoreEngine> g_engine;
std::mutex g_engineMutex;

sxv::SxvCoreEngine& engine() {
    std::lock_guard<std::mutex> lock(g_engineMutex);
    if (!g_engine) {
        g_engine = std::make_unique<sxv::SxvCoreEngine>();
    }
    return *g_engine;
}
} // namespace

extern "C" JNIEXPORT void JNICALL
Java_com_sxv_gamespace_NativeBridge_nativeInit(JNIEnv* env, jobject /* thiz */) {
    (void) env;
    engine(); // memastikan instance terbentuk
    LOGI("SxvCoreEngine diinisialisasi");
}

// Memvalidasi command. Mengembalikan command yang sudah divalidasi,
// atau null (jstring nullptr) jika ditolak — Kotlin WAJIB memeriksa
// null sebelum mengeksekusi via Shizuku.
extern "C" JNIEXPORT jstring JNICALL
Java_com_sxv_gamespace_NativeBridge_nativeValidateCommand(
        JNIEnv* env, jobject /* thiz */, jstring rawCommand) {
    const char* raw = env->GetStringUTFChars(rawCommand, nullptr);
    std::string cmd(raw);
    env->ReleaseStringUTFChars(rawCommand, raw);

    auto result = engine().validateCommand(cmd);
    if (!result.has_value()) {
        return nullptr;
    }
    return env->NewStringUTF(result->c_str());
}

// Mengembalikan statistik sistem sebagai array [cpuPercent*100, totalRamKb, availRamKb]
// (dikonversi ke jfloatArray agar mudah dipetakan ke Kotlin data class di sisi caller).
extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_sxv_gamespace_NativeBridge_nativeReadSystemStats(
        JNIEnv* env, jobject /* thiz */) {
    auto stats = engine().readSystemStats();

    jfloatArray result = env->NewFloatArray(3);
    if (result == nullptr) {
        return nullptr;
    }
    jfloat values[3] = {
            stats.cpuUsagePercent,
            static_cast<jfloat>(stats.totalRamKb),
            static_cast<jfloat>(stats.availableRamKb),
    };
    env->SetFloatArrayRegion(result, 0, 3, values);
    return result;
}

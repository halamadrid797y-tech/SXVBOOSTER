#ifndef SXV_CORE_ENGINE_H
#define SXV_CORE_ENGINE_H

#include <string>
#include <optional>

namespace sxv {

/**
 * SxvCoreEngine
 * ------------------------------------------------------------
 * Lapisan native untuk:
 *   1) Validasi & whitelisting perintah shell sebelum
 *      diteruskan ke eksekutor privileged (Shizuku) di Kotlin.
 *      Ini adalah lapisan pertahanan kedua — validasi utama
 *      tetap harus ada di sisi Kotlin/UI.
 *   2) Membaca metrik performa lokal (CPU & RAM) langsung dari
 *      /proc, tanpa memerlukan shell privileged, untuk
 *      Performance Monitor overlay.
 *
 * CATATAN ARSITEKTUR:
 * Modul ini SENGAJA tidak mengimplementasikan ulang protokol
 * ADB (SPAKE2 pairing, TLS, auth handshake) dari nol. Protokol
 * tersebut sudah diimplementasikan secara matang & teruji oleh
 * proyek Shizuku (open source). Mengimplementasikan ulang stack
 * kriptografi/koneksi tersebut secara native berisiko tinggi
 * (celah keamanan, ketidakcocokan versi Android) dan tidak
 * memberi nilai tambah dibanding memanfaatkan Shizuku API yang
 * sudah stabil. Eksekusi command privileged aktual dilakukan
 * oleh NativeBridge.kt via Shizuku.newProcess(), dipanggil balik
 * dari sini lewat JNI upcall setelah command dinyatakan aman.
 */
class SxvCoreEngine {
public:
    struct SystemStats {
        float cpuUsagePercent = 0.0f;
        long totalRamKb = 0;
        long availableRamKb = 0;
    };

    SxvCoreEngine();

    // Memvalidasi sebuah perintah shell terhadap blacklist/whitelist.
    // Mengembalikan std::nullopt jika command ditolak.
    std::optional<std::string> validateCommand(const std::string& rawCommand);

    // Membaca statistik CPU & RAM terkini dari /proc/stat & /proc/meminfo.
    SystemStats readSystemStats();

private:
    long prevIdleTicks_ = 0;
    long prevTotalTicks_ = 0;

    bool isBlacklisted(const std::string& cmd) const;
    bool isWhitelistedPrefix(const std::string& cmd) const;
};

} // namespace sxv

#endif // SXV_CORE_ENGINE_H
